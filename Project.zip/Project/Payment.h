#ifndef PAY
#define PAY

#include <iostream>
using namespace std;

class Payment {
protected:
  string paymentId;
  float amount;
  string payment_type;
  string paymentDate;

public:
  Payment();
  Payment(string paytId, float amt, string paytype, string paydate);
  void setDetails(string paytId, float amt, string paytype,
                          string paydate);
  string getDetails();
  void display();
  ~Payment();
};

#endif