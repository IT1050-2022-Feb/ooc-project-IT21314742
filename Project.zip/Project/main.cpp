#include "Card_payment.h"
#include "Cash_on_delivery.h"
#include "Payment.h"
#include <iostream>
using namespace std;

int main() {

  Payment pay1("PAY1100", 35000.00, "CARD_DEBIT", "2022-01-20");

  Cash_on_delivery c1("Dmindu", "Puttalam", 35000.00);

  Card_payment card1(3740126, "CREDIT", 121);

  return 0;
}