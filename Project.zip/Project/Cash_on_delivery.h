#include "Payment.h"
#include<iostream>
using namespace std;

class Cash_on_delivery : public Payment{
private:
  string customerName;
  string customerAddress;
  float amount;
public:
  Cash_on_delivery();
  Cash_on_delivery(string cusname,string cusadd,float amt);
  void setDetails(string cusname,string cusadd,float amt);
  string getDetails();
  float getAmount();
  void display();
  ~Cash_on_delivery();
}; 