#include "Payment.h"

Payment::Payment() {
  cout << "Default Payment constructor called " << endl << endl;
}
Payment::Payment(string paytId, float amt, string paytype, string paydate) {
  paymentId = paytId;
  amount = amt;
  payment_type = paytype;
  paymentDate = paydate;

  cout << "Payment Overloaded Constructor Called" << endl;
  // cout << "PAYMENT ID : " << paymentId << endl
  //      << "AMOUNT : " << amount << endl
  //      << "PAYMENT TYPE: " << payment_type << endl
  //      << "PAYMENT DATE : " << paymentDate << endl<<endl;
  // cout<<"Values assigned successuly"<< endl;
}
void Payment::setDetails(string paytId, float amt, string paytype, string paydate) {}
string Payment::getDetails() {}
Payment::~Payment() { 

  cout << "Payment Destructor called " << endl; 
  
}