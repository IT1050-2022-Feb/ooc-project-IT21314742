#include "Card_payment.h"

Card_payment::Card_payment() {
  cout << "Default Card_payment constructor called " << endl << endl;
}
Card_payment::Card_payment(int cNo,string ctype,int cvNo) {
  // parent class attributes

  paymentId = "PAY2200";
  payment_type = "CARD_CREDIT";
  paymentDate = "2020-01-20";
  
  // child class attributes
  cardNo=cNo;
  type=ctype;
  cvcNo=cvNo;

  cout << "Card_payment Overloaded Constructor Called" << endl;
  cout << "CARD-NUMER : " << cardNo << endl
       << "CARD-TYPE : " << type << endl
       << "CVC-NUMBER : " << cvcNo << endl
       << "PAYMENT TYPE: " << payment_type << endl
       << "PAYMENT DATE : " << paymentDate << endl
       << endl;
}
void Card_payment::setDetails(int cNo,string ctype,int cvNo){}
string Card_payment::gettype(){}
int Card_payment::getcarddetails(){}
void Card_payment::display(){}
Card_payment::~Card_payment() {
  cout << "Card_payment destructor called " << endl << endl;
}