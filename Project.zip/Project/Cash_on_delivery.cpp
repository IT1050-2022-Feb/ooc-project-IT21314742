#include "Cash_on_delivery.h"

Cash_on_delivery::Cash_on_delivery() {
  cout << "Default Cash_on_delivery constructor called " << endl << endl;
}
Cash_on_delivery::Cash_on_delivery(string cusname, string cusadd, float amt) {
  // parent class attributes

  paymentId = "PAY1100";
  payment_type = "CARD_DEBIT";
  paymentDate = "2022-01-20";
  
  // child class attributes
  customerName = cusname;
  customerAddress = cusadd;
  amount = amt;

  cout << "Cash_on_Delivery Overloaded Constructor Called" << endl;
  cout << "CUSTOMER-NAME : " << customerName << endl
       << "CUSTOMER-ADDRESS : " << customerAddress << endl
       << "AMOUNT : " << amount << endl
       << "PAYMENT ID : " << paymentId << endl
       << "PAYMENT TYPE: " << payment_type << endl
       << "PAYMENT DATE : " << paymentDate << endl
       << endl;
}
void Cash_on_delivery::setDetails(string cusname, string cusadd, float amt) {}
string Cash_on_delivery::getDetails() {}
float Cash_on_delivery::getAmount() {}
void Cash_on_delivery::display() {}
Cash_on_delivery::~Cash_on_delivery() {
  cout << "Cash_on_delivery destructor called " << endl << endl;
}