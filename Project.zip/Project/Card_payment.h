#include "Payment.h"
#include<iostream>
using namespace std;

class Card_payment : public Payment{
private:
  int cardNo;
  string type;
  int cvcNo;
public:
  Card_payment();
  Card_payment(int cNo,string ctype,int cvNo);
  void setDetails(int cNo,string ctype,int cvNo);
  string gettype();
  int getcarddetails();
  void display();
  ~Card_payment();
}; 